import { useEffect, useRef } from 'react'
import { useWords } from '../../store/wordsContext.jsx'
import WordCardEditable from '../WordCardEditable/WordCardEditable'
import WordCard from '../WordCard/WordCard'
import AddWordButton from '../WordAddNew/WordAddNew'
import './WordList.scss'

const WordList = () => {
    const {
        words,
        tags,
        mode,
        addWord,
        deleteWord,
        updateWord,
        clearEmptyCards,
    } = useWords()

    const addedInitialWords = useRef(false)

    const filteredWords = words.filter((w) => w.tags === tags)

    useEffect(() => {
        addedInitialWords.current = false
    }, [tags])

    useEffect(() => {
        if (
            mode === 'edit' &&
            filteredWords.length === 0 &&
            !addedInitialWords.current
        ) {
            addWord()
            addWord()
            addWord()
            addedInitialWords.current = true
        }
    }, [filteredWords.length, mode, tags])

    useEffect(() => {
        return () => {
            clearEmptyCards()
        }
    }, [])

    return (
        <div className="word_list_wrapper">
            {filteredWords.map((wordData, index) =>
                mode === 'edit' ? (
                    <WordCardEditable
                        key={wordData.id}
                        id={wordData.id}
                        index={index}
                        initialData={wordData}
                        onDelete={deleteWord}
                        onChange={(newData) => updateWord(wordData.id, newData)}
                    />
                ) : (
                    <WordCard key={wordData.id} index={index} word={wordData} />
                )
            )}
            {mode === 'edit' && <AddWordButton onClick={addWord} />}
        </div>
    )
}

export default WordList
