import { useState, useEffect } from 'react'
import Controls from '../Controls'
import './WordCardEditable.scss'
import DeleteIcon from '../../assets/icons/delete.svg?react'

const WordCardEditable = ({ data = {}, onChange, onDelete, index = 0 }) => {
    const [english, setEnglish] = useState(data.english || '')
    const [transcription, setTranscription] = useState(data.transcription || '')
    const [russian, setRussian] = useState(data.russian || '')
    const [error, setError] = useState(false)

    // 💾 синхронно отправляем изменения родителю
    useEffect(() => {
        if (onChange) {
            onChange({
                ...data,
                english,
                transcription,
                russian,
            })
        }
    }, [english, transcription, russian])

    const handleChange = (field, value) => {
        if (field === 'english') {
            setError(value.trim() === '')
            setEnglish(value)
        } else if (field === 'transcription') {
            setTranscription(value)
        } else if (field === 'russian') {
            setRussian(value)
        }
    }

    return (
        <div className="editable_card_wrapper">
            <div className="editable_card_text">{index + 1}</div>

            <div className="editable_card_fields_wrapper">
                <Controls.Input
                    label="Английское слово"
                    value={english}
                    onChange={(e) => handleChange('english', e.target.value)}
                    error={error}
                />
                <Controls.Input
                    label="Транскрипция"
                    value={transcription}
                    onChange={(e) =>
                        handleChange('transcription', e.target.value)
                    }
                />
                <div className="editable_card_text">–</div>
                <Controls.Input
                    label="Перевод"
                    value={russian}
                    onChange={(e) => handleChange('russian', e.target.value)}
                />
            </div>

            <div className="editable_card_fields_delete_wrapper">
                <button
                    className="transparent_icon_btn"
                    onClick={() => onDelete?.(data.id)}
                >
                    <DeleteIcon />
                </button>
            </div>
        </div>
    )
}

export default WordCardEditable
