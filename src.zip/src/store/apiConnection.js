// api.js

// Получить все слова
export const getWords = async () => {
    const response = await fetch('http://itgirlschool.justmakeit.ru/api/words')
    if (!response.ok) throw new Error('Ошибка загрузки слов')
    return await response.json()
}

// Отправить одно слово с действием add/update/delete
export const sendWord = async (word, action) => {
    let url = ''
    switch (action) {
        case 'add':
            url = 'http://itgirlschool.justmakeit.ru/api/words/add'
            break
        case 'update':
            url = `http://itgirlschool.justmakeit.ru/api/words/${word.id}/update`
            break
        case 'delete':
            url = `http://itgirlschool.justmakeit.ru/api/words/${word.id}/delete`
            break
        default:
            throw new Error(`Неизвестное действие: ${action}`)
    }

    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(word),
    })

    if (!response.ok) {
        throw new Error(
            `Ошибка при ${action} слова ${word.id}: ${response.status}`
        )
    }

    return await response.json()
}

// Отправить несколько слов параллельно
export const sendWords = async (words, serverActions) => {
    const promises = words.map((word) => {
        const action = serverActions[word.id]
        if (!action) return Promise.resolve()
        return sendWord(word, action)
    })
    return Promise.all(promises)
}
